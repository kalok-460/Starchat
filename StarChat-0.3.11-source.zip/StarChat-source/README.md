# StarChat 0.3.11

Star Citizen의 영어 채팅을 읽고 번역하는 Windows 도구입니다. 게임 OCR과 Spectrum 채팅을 별도의 오버레이로 표시합니다. RSI/Cloud Imperium Games의 공식 제품이 아닙니다.

## 실행

1. `StarChat-0.3.11-win-x64.zip` 전체를 쓰기 가능한 폴더에 압축 해제합니다. exe만 따로 옮기지 마세요.
2. Windows 10 (2004 이상) 또는 Windows 11 x64, .NET Framework 4.7.2 이상, Microsoft Edge WebView2 Runtime이 필요합니다. [WebView2 공식 설치](https://developer.microsoft.com/microsoft-edge/webview2/), [.NET 공식 설치](https://dotnet.microsoft.com/download/dotnet-framework).
3. `StarChat.exe` 또는 `Start-StarChat.cmd`를 실행합니다. DirectML GPU/CPU 런타임과 PP-OCRv6 small ONNX 검출·인식 모델이 포함되어 있습니다.
4. 설정 → 일반에서 UI 언어를 한국어/English로 선택할 수 있습니다. UI 언어는 재실행 시 적용되며 채팅 번역 언어와 별도입니다. 함께 실행할 프로그램은 최대 3개입니다.
5. OCR 영역을 게임 채팅에 맞추고 앱 채팅 열기 키와 게임 채팅 열기 키를 설정하세요. 입력 모드에서 이동·크기 조절·우클릭을 사용할 수 있습니다.

## GPU 사용

PP-OCRv6 small의 공식 ONNX 검출·인식 모델을 ONNX Runtime DirectML로 실행합니다. 배포본에 ONNX Runtime과 DirectML 구성 요소, CPU 실행 경로가 모두 포함되어 있습니다. CUDA, cuDNN, PaddlePaddle 또는 별도 GPU 설치 스크립트가 필요하지 않습니다. 앱 시작 시 GPU 설치 안내창을 표시하지 않습니다.

DirectX 12를 지원하는 NVIDIA·AMD Radeon·Intel GPU에서 가속을 시도합니다. 여러 GPU가 있으면 고성능 GPU를 우선 선택합니다. 초기화 실패나 실행 중 GPU 오류가 발생하면 동일한 모델로 CPU OCR에 전환합니다. 실제 지원 여부와 속도는 GPU·드라이버에 따라 달라집니다. DirectML 메모리 아레나와 CPU 스핀 대기를 끄며, 전체 VRAM의 일정 비율을 미리 확보하지 않습니다. 모델과 추론에 필요한 GPU 메모리는 사용합니다.

출처: [DirectML 실행 공급자](https://onnxruntime.ai/docs/execution-providers/DirectML-ExecutionProvider.html), [검출 ONNX 모델](https://huggingface.co/PaddlePaddle/PP-OCRv6_small_det_onnx), [인식 ONNX 모델](https://huggingface.co/PaddlePaddle/PP-OCRv6_small_rec_onnx).

## 기능과 데이터

- Google(기본), GPT, Gemini, DeepL, Papago, Ollama 번역. 각 서비스의 계정·키·사용 요금 및 제한은 별도입니다. Google 키 없는 웹 번역은 요청 제한을 받을 수 있습니다.
- OCR은 영어를 인식합니다. 단일 틱의 위치 검출, 새 행 부분 인식, 10회마다 전체 재확인 구조입니다. 색상을 유지한 CLAHE 전처리를 사용합니다.
- OCR/Spectrum 별도 영역, 방별 번역과 Tab 전환, 알림, 친구·그룹·1:1 대화 기능. Spectrum의 메시지 위치와 표시 영역은 입력창 활성화 여부와 관계없이 동일합니다.
- RSI 로그인은 앱 내부의 공식 웹 페이지에서 합니다. 설정과 WebView 세션은 `%LOCALAPPDATA%\StarChat`에 저장됩니다. API 키는 Windows 사용자 계정으로 암호화됩니다.
- OCR 기록만 설정한 폴더에 저장합니다. Spectrum 대화는 앱을 종료하면 메모리에서 사라지며 서버에 보관됩니다. 로그아웃은 로그인 세션을 지우고 OCR 기록은 남깁니다.
- 온라인 번역에는 인식한 채팅 내용이 선택한 서비스에 전송됩니다. 로컬 Ollama를 선택하면 해당 로컬 서버를 사용합니다.
- 이 배포본에는 제작자의 설정·API 키·로그인 세션·채팅 기록·녹화 파일이 포함되지 않습니다.

## 소스 빌드 / 검사

소스 ZIP을 압축 해제하고 PowerShell에서 실행하세요. Windows x64와 .NET Framework의 C# 컴파일러를 사용합니다.

```powershell
.\build.ps1
.\run-core-tests.ps1
.\run-translation-tests.ps1
.\run-ocr-regressions.ps1
.\run-ui-tests.ps1
node --test test-bridge.cjs
```

UI 검사는 자체 테스트 창에만 키를 전달합니다. 실계정 API나 게임 전송을 수행하지 않습니다. WebView2 SDK 파일은 `deps/`에 포함됩니다. OCR 런타임을 새로 준비하려면 `ocr/setup.ps1`을 실행하세요(인터넷 필요). Python 검사: `ocr/runtime/python.exe -m unittest discover -s ocr -p 'test_*.py'`. 소스만 빌드한 앱에는 OCR 모델/런타임 설치가 필요합니다.

배포 파일 생성: `package.ps1 -Version 0.3.11 -DestinationRoot <새로운 절대경로>` (`build.ps1`, `ocr/setup.ps1` 완료 후). 패키징은 허용 목록만 사용하며 기존 목적지 폴더를 덮어쓰지 않습니다. 모델은 small 두 개만 포함합니다.

## 라이선스

StarChat의 자체 소스코드는 GNU GPL **버전 3** (`GPL-3.0-only`)으로 제공됩니다. 전체 조건은 `LICENSE`를 확인하세요. 보증 없이 제공됩니다. 바이너리를 배포할 때 같은 버전의 대응 소스코드도 함께 제공하세요. 서드파티 구성 요소는 `THIRD_PARTY_NOTICES.txt`와 각 원본 라이선스를 따릅니다. Star Citizen/Spectrum 명칭·로고는 각 권리자에게 속하며 GPL 코드 라이선스가 해당 브랜드 권리를 부여하지 않습니다.

---

## English quick start

StarChat is an independent Windows chat companion for Star Citizen. Extract the entire Windows ZIP into a writable folder and run `StarChat.exe`. Windows 10 (2004+)/11 x64, .NET Framework 4.7.2+ and the Microsoft Edge WebView2 Runtime are required. The DirectML GPU/CPU runtime and PP-OCRv6 small ONNX models are included.

Choose **Settings → General → UI language → English**, save, then restart. The UI language is separate from the chat translation language. Select up to three companion executables in General settings. Set the OCR region and both chat activation keys before playing.

ONNX Runtime DirectML and both PP-OCRv6 small ONNX models are bundled. No PaddlePaddle, CUDA, cuDNN or GPU installer is required. DirectX 12-capable NVIDIA, AMD Radeon and Intel GPUs are supported through DirectML, with a high-performance GPU preference and automatic CPU fallback if GPU initialization or execution fails. There is no startup installation prompt. GPU memory is allocated for inference without pre-reserving a percentage of total VRAM. Actual performance and compatibility depend on hardware and drivers.

Spectrum messages retain the same viewport, wrapping and screen position when the input controls are hidden.

Sign in using the official RSI page inside the app. Credentials/settings are stored locally in `%LOCALAPPDATA%\StarChat`, not beside the executable. Only OCR history is persisted; logging out keeps that history. Online translation sends chat text to the selected provider; local Ollama uses your local server. No developer credentials or personal history are shipped.

Build with `build.ps1`; run the tests listed above. Install OCR dependencies with `ocr/setup.ps1`. The source is GPL-3.0-only; distribute the matching source alongside binaries. See `LICENSE` and `THIRD_PARTY_NOTICES.txt` for complete terms and vendor notices. This is not an official RSI/CIG product.
