﻿# SPDX-License-Identifier: GPL-3.0-only
# Copyright (C) 2026 StarChat contributors
$ErrorActionPreference = 'Stop'
$uiTestRoot = $PSScriptRoot
$uiCompiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$uiSources = @('I18n.cs','Core.cs','Native.cs','OcrClient.cs','Spectrum.cs','Translation.cs','Overlay.cs','Visuals.cs','SettingsForm.cs','MainForm.cs','UiTests.cs') | ForEach-Object { Join-Path $uiTestRoot $_ }
& $uiCompiler /nologo /target:winexe /main:StarChat.UiTests /langversion:5 /platform:x64 /codepage:65001 /optimize+ "/out:$uiTestRoot\UiTests.exe" /reference:System.Management.dll /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.Web.Extensions.dll /reference:System.Net.Http.dll /reference:System.Security.dll "/reference:$uiTestRoot\Microsoft.Web.WebView2.Core.dll" "/reference:$uiTestRoot\Microsoft.Web.WebView2.WinForms.dll" $uiSources
if ($LASTEXITCODE -ne 0) { throw "UI test compilation failed: $LASTEXITCODE" }
$uiProcess = Start-Process -FilePath (Join-Path $uiTestRoot 'UiTests.exe') -WorkingDirectory $uiTestRoot -WindowStyle Hidden -PassThru
if (-not $uiProcess.WaitForExit(30000)) { $uiProcess.Kill(); throw 'UI tests exceeded 30 seconds; stopped this test process.' }
$uiResult = Join-Path $uiTestRoot 'test-output\ui-tests.json'
Get-Content -LiteralPath $uiResult -Raw
if ($uiProcess.ExitCode -ne 0) { throw "UI tests failed: $($uiProcess.ExitCode)" }
